/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Nhacungcap;

/**
 *
 * @author geekguy
 */
public interface NhacungcapDAO {
    // create
    public boolean create(Nhacungcap object);
 
    // update
    public boolean update(Nhacungcap object);
 
    // delete
    public boolean delete(Nhacungcap object);
 
    // find by id
    public Nhacungcap findById(char nccID);
 
    // load list by nav
    public List<Nhacungcap> getListNav(int start, int limit);
    
    // total item
    public int totalItem();
}
