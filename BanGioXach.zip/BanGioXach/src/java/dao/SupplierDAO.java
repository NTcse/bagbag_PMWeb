/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.HibernateUtil;
import model.Nhacungcap;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author geekguy
 */
public class SupplierDAO {
    public List<Nhacungcap> findAll(){
        List<Nhacungcap> list = new ArrayList<Nhacungcap>();
        Session sess = HibernateUtil.getSessionFactory().openSession();
        try {
            Transaction tx = sess.getTransaction();
            tx.begin();
            Criteria cr = sess.createCriteria(Nhacungcap.class);
            list = cr.list();
            
         
            tx.commit(); 
            sess.close();
            return list;
        } catch (Exception e) {
            System.out.println("Lỗi");
        }                            
        return list;
    }
    public void save(Nhacungcap p){
        Session sess = HibernateUtil.getSessionFactory().openSession();
        try {
            Transaction tx = sess.getTransaction();
            tx.begin();
            
            sess.save(p);
            
            tx.commit(); 
            sess.close();
        } catch (Exception e) {
            System.out.println("Lỗi");
        }
       
    }
    
    public void delete(Nhacungcap p){
        Session sess = HibernateUtil.getSessionFactory().openSession();
        try {
            Transaction tx = sess.getTransaction();
            tx.begin();
         
            sess.delete(p);
         
            tx.commit(); 
            sess.close();
        } catch (Exception e) {
            System.out.println("Lỗi");
        }

    }
    public void update(Nhacungcap p){
        Session sess = HibernateUtil.getSessionFactory().openSession();
        try {
            Transaction tx = sess.getTransaction();
            tx.begin();
         
            sess.saveOrUpdate(p);
         
            tx.commit(); 
            sess.close();
        } catch (Exception e) {
            System.out.println("Lỗi");
        }
    }
    public Nhacungcap get(String id)
    {
        Session sess = HibernateUtil.getSessionFactory().openSession();
        try {
            Transaction tx = sess.getTransaction();
            tx.begin();
            Nhacungcap p = (Nhacungcap) sess.get(Nhacungcap.class,id);
                
            
                 
            tx.commit(); 
            sess.close();
            return p ;
        } catch (Exception e) {
            System.out.println("Lỗi");
        }
        return null;
    }
}
