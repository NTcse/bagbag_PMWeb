
package controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.HibernateUtil;
import model.Khachhang;
import model.Tuixach;
import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@Controller
@SessionAttributes("khachhang")
public class LoginController{
    @RequestMapping(value = "login.htm", method = RequestMethod.GET)
    public String Login()
    {
        return "login";
    }
    @RequestMapping(value = "login.htm", method = RequestMethod.POST)
    
    public String login(ModelMap mv, HttpServletRequest hsr)
    {
        
        
        String out ="Đăng nhập Thất Bại";
        String sdt= hsr.getParameter("numberphone");
        String pass=hsr.getParameter("password");
       
        
        try{
            if(sdt==null || pass==null)
            {
                out="Hãy nhập Number Phone và password";
                mv.addAttribute("messenger",out);
                return "login";
            }
            else
            {
                Session sess= HibernateUtil.getSessionFactory().openSession();
                sess.beginTransaction();
                Khachhang kh=(Khachhang) sess.get(Khachhang.class, sdt);
           
                if(kh!=null)
                {  
                    if(kh.getMatkhau().equals(pass))
                    {
                        mv.addAttribute("khachhang",kh);
                        out="Đăng nhập Thành công";
                        mv.addAttribute("messenger",out);
                        if(kh.getKieu().equals("admin"))
                        {
                            sess.getTransaction().commit();
                            sess.close();
                            return "admin";
                        }
                        else
                        {
                            List<Tuixach> bags=sess.createQuery("from Tuixach").list();
                            mv.addAttribute("bags", bags);
                            sess.getTransaction().commit();
                            sess.close();
                            return "home";
                        }

                    }
                    else 
                    {
                        out="Sai Mật Khẩu";
                        mv.addAttribute("messenger",out);
                        sess.getTransaction().commit();
                        sess.close();
                        return "login";
                    }
                }
                else 
                {
                    out="Tài khoản không tồn tại";
                    mv.addAttribute("messenger",out);
                    sess.getTransaction().commit();
                    sess.close();
                    return "login";
                }

            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return "index";
    }
    
}