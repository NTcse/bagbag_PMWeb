package controller;

import java.util.List;
import model.HibernateUtil;
import model.Hoadon;
import org.hibernate.Session;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

public class InvoiceController {
    @RequestMapping(value="/quan-ly-hoa-don")
    public String home(ModelMap model)
    {
        model.addAttribute("message", "Đây là trang Quản lý Hóa đơn!");
        
        Session sess= HibernateUtil.getSessionFactory().openSession();
            sess.beginTransaction();
            List<Hoadon> invoices=sess.createQuery("from Hoadon").list();
            model.addAttribute("invoices", invoices);
            sess.getTransaction().commit();
            sess.close();
        
        return "QuanLyHoaDon";
    }
}
