package controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.HibernateUtil;
import model.Khachhang;
import model.Tuixach;
import org.hibernate.Session;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

public class BagController {
    @RequestMapping(value="quan-ly-tui-xach")
    public String home(ModelMap model)
    {
        model.addAttribute("message", "Đây là trang Quản lý túi xách!");
        
        Session sess= HibernateUtil.getSessionFactory().openSession();
            sess.beginTransaction();
            List<Tuixach> bags=sess.createQuery("from Tuixach").list();
            model.addAttribute("bags", bags);
            sess.getTransaction().commit();
            sess.close();
        
        return "QuanLyTuiXach";
    }
    
    @RequestMapping(value="Delete{matuixach}.htm", params="DeleteBag")
    public String DeleteBag(ModelMap mv, HttpServletRequest hsr, @PathVariable("matuixach") String bag , HttpServletResponse hsp)
    {
            Session sess= HibernateUtil.getSessionFactory().openSession();
            sess.beginTransaction();
            Tuixach b=(Tuixach) sess.get(Tuixach.class,bag); //tạo lại đối tượng
            sess.delete(b); // xóa đối tượng
            sess.getTransaction().commit();
            sess.close();
            mv.addAttribute("message","thanh cong");
            return "QuanLyTuiXach";
    }
}
