package controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.HibernateUtil;
import model.Khachhang;
import model.Nhacungcap;
import org.hibernate.Session;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

public class SupplierController {
    @RequestMapping(value="quan-ly-nha-cung-cap.htm")
    public String ShowHome(ModelMap model)
    {
        model.addAttribute("message", "Đây là trang Quản lý Nhà cung cấp!");
        
        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        List<Nhacungcap> suppliers=sess.createQuery("from Nhacungcap").list();
        model.addAttribute("suppliers", suppliers);
        model.addAttribute("messageAD", "Load Thành Công");
        sess.getTransaction().commit();
        sess.close();
        
        return "admin";
    }
    @RequestMapping(value="Delete={manhacungcap}.htm", params="linkDeleteSupplier")
    public String DeleteByID (ModelMap model,HttpServletRequest hsr, @PathVariable("manhacungcap") String supplier ,HttpServletResponse hsp)
    {         
        String out="Không có quyền thực hiện";
        Khachhang kh=(Khachhang) hsr.getSession().getAttribute("std");
        if(!kh.getKieu().equals("admin"))
        {
            model.addAttribute("messgerAD",out);
            return "admin";
        }
        else
        {
            Session sess= HibernateUtil.getSessionFactory().openSession();
            sess.beginTransaction();
            Nhacungcap ncc=(Nhacungcap) sess.get(Nhacungcap.class,supplier); //tạo lại đối tượng
            sess.delete(ncc); // xóa đối tượng
            Nhacungcap kt=(Nhacungcap) sess.get(Nhacungcap.class,supplier);
            if(kt==null)
                out="Xóa thành công "+supplier;
            else
                out="Xóa "+supplier+" thất bại";
            sess.getTransaction().commit();
            sess.close();
            model.addAttribute("messageAD",out);
            return "admin";
        }
//    
/*        Session sess= HibernateUtil.getSessionFactory().openSession();
        sess.beginTransaction();
        Nhacungcap sup=(Nhacungcap) sess.get(Nhacungcap.class, supplier);
        sess.delete(sup); // xóa đối tượng
        sess.getTransaction().commit();
        sess.close();
        model.addAttribute("message", "xoa thanh cong");
        return "QuanLyNhaCungCap";*/
    }
}
