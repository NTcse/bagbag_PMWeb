package controller;

import java.util.List;
import model.HibernateUtil;
import model.Tuixach;
import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
    @RequestMapping(value="/home")
    public String home(ModelMap model)
    {
        model.addAttribute("message", "Đây là trang Contact!");
        
        Session sess= HibernateUtil.getSessionFactory().openSession();
            sess.beginTransaction();
            List<Tuixach> bags=sess.createQuery("from Tuixach").list();
            model.addAttribute("bags", bags);
            sess.getTransaction().commit();
            sess.close();
        
        return "home";
    }
}
