package controller;

import java.util.List;
import model.HibernateUtil;
import model.Khachhang;
import org.hibernate.Session;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

public class CustomerController {
    @RequestMapping(value="/quan-ly-khach-hang")
    public String home(ModelMap model)
    {
        model.addAttribute("message", "Đây là trang Quản lý khách hàng!");
        
        Session sess= HibernateUtil.getSessionFactory().openSession();
            sess.beginTransaction();
            List<Khachhang> customers=sess.createQuery("from Khachhang").list();
            model.addAttribute("customers", customers);
            sess.getTransaction().commit();
            sess.close();
        
        return "QuanLyKhachHang";
    }
}
