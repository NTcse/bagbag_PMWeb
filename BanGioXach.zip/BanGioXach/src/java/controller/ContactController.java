package controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

public class ContactController {
    @RequestMapping(value="/contact")
    public String home(ModelMap model)
    {
        model.addAttribute("message", "Đây là trang Contact!");
        return "contact";
    }
}
