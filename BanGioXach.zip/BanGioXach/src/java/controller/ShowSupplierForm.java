/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author geekguy
 */
public class ShowSupplierForm {
    @RequestMapping(value="/form-them-nha-cung-cap")
    public String home(ModelMap model)
    {
        model.addAttribute("message", "Đây là trang Thêm nhà cung cấp!");
        return "FormThemNhaCungCap";
    }
    @RequestMapping(value="/insertSupplier")
    public String insert(ModelMap model)
    {
        model.addAttribute("message", "Đây là trang Thêm nhà cung cấp!");
        return "FormThemNhaCungCap";
    }
}
