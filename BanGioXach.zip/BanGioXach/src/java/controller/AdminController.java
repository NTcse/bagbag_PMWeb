
package controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.HibernateUtil;
import model.Khachhang;
import model.Tuixach;
import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
//@RequestMapping("/admin/")
public class AdminController 
{ 
    @RequestMapping(value = "admin.htm", method = RequestMethod.GET)
    public String Admin( ModelMap mv, HttpServletRequest hsr)
    {
        String out="0";
        mv.addAttribute("adminMessage",out);
        return "home";
    }
    @RequestMapping(value="loadtuixachs.htm",method = RequestMethod.GET)
    public String AdminLoadTuixach(ModelMap mv, HttpServletRequest hsr)
    {
        String out="Xử lý thất bại hoặc không có quyền truy cập";
        Khachhang kh1=(Khachhang) hsr.getSession().getAttribute("khachhang");
        if(!kh1.getKieu().equals("admin"))
        {
            out="Không thực hiện được";
            mv.addAttribute("adminMessage",out);
            mv.addAttribute("messenger",out);
            return "admin";
        }
        else
        {
            out="Load dữ liệu thành công";
            mv.addAttribute("adminMessage",out);         
            Session sess= HibernateUtil.getSessionFactory().openSession();
            sess.beginTransaction();
            List<Tuixach> List_tui_xach=sess.createQuery("from Tuixach").list();
            mv.addAttribute("tuixachs", List_tui_xach);
            sess.getTransaction().commit();
            sess.close();
            return "admin";
        }
    }
}