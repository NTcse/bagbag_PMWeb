/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author geekguy
 */
public class InsertSupplier {
    @RequestMapping(value="/insert-Supplier")
    public String home(ModelMap model)
    {
        model.addAttribute("message", "Đây là trang Contact!");
        return "QuanLyNhaCungCap";
    }
}
