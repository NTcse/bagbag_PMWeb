package service;

import dao.NhacungcapDAO;
import java.util.List;
import model.Nhacungcap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NhacungcapServiceImpl implements NhacungcapService{
    @Autowired
    private NhacungcapDAO NhacungcapDAO;
 
    @Override
    public boolean create(Nhacungcap object) {
        return NhacungcapDAO.create(object);
    }
 
    @Override
    public boolean update(Nhacungcap object) {
        return NhacungcapDAO.update(object);
    }
 
    @Override
    public boolean delete(Nhacungcap object) {
        return NhacungcapDAO.delete(object);
    }
 
    @Override
    public Nhacungcap findById(char nccID) {
        return NhacungcapDAO.findById(nccID);
    }
 
    @Override
    public List<Nhacungcap> getListNav(int start, int limit) {
        return NhacungcapDAO.getListNav(start, limit);
    }
 
    @Override
    public int totalItem() {
        return NhacungcapDAO.totalItem();
    }
}
