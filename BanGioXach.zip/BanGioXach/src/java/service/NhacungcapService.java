
package service;

import java.util.List;
import model.Nhacungcap;

public interface NhacungcapService {
    
    // create
    public boolean create(Nhacungcap object);
 
    // update
    public boolean update(Nhacungcap object);
 
    // delete
    public boolean delete(Nhacungcap object);
 
    // find by id
    public Nhacungcap findById(char nccID);
 
    // load list by nav
    public List<Nhacungcap> getListNav(int start, int limit);
    
    // total item
    public int totalItem();
    
}